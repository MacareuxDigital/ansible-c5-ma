<?php
namespace Concrete\Controller\Dialog\Page;

class Clipboard extends \Concrete\Controller\Panel\Add
{
    protected $viewPath = '/dialogs/page/clipboard';
}
