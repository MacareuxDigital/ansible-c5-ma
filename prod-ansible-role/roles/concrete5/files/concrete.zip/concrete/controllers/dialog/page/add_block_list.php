<?php
namespace Concrete\Controller\Dialog\Page;

class AddBlockList extends \Concrete\Controller\Panel\Add
{
    protected $viewPath = '/dialogs/page/add_block_list';
}
