<?php
defined('C5_EXECUTE') or die("Access Denied.");
print $rating->output($this->field('value'), $caValue);